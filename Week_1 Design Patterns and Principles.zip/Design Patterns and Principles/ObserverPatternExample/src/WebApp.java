public class WebApp implements Observer {
    private String siteName;

    public WebApp(String siteName) {
        this.siteName = siteName;
    }

    @Override
    public void update(double price) {
        System.out.println(siteName + " received stock price update: " + price);
    }
}