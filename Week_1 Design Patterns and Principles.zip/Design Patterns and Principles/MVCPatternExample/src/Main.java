import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Student model = new Student("5", "Suprava Panda", "A");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(model, view);
        controller.updateView();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter new student name:");
        String name = scanner.nextLine();
        controller.setStudentName(name);

        System.out.println("Enter new student ID:");
        String id = scanner.nextLine();
        controller.setStudentId(id);

        System.out.println("Enter new student grade:");
        String grade = scanner.nextLine();
        controller.setStudentGrade(grade);

        // Update view again with new details
        controller.updateView();

        scanner.close();
    }
}
