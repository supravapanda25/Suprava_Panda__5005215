import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        CustomerService customerService = new CustomerService(customerRepository);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter customer ID:");
        String id = scanner.nextLine();

        Customer customer = customerService.getCustomerById(id);

        System.out.println(customer);

        scanner.close();
    }
}