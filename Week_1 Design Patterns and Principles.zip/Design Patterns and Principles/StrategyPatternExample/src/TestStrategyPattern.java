import java.util.Scanner;

public class TestStrategyPattern {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Select payment method: 1. Credit Card 2. PayPal 3. Exit");
            int choice = scanner.nextInt();

            if (choice == 3) {
                break;
            }

            System.out.println("Enter amount:");
            double amount = scanner.nextDouble();

            switch (choice) {
                case 1:
                    scanner.nextLine();
                    System.out.println("Enter card number:");
                    String cardNumber = scanner.nextLine();
                    System.out.println("Enter card holder name:");
                    String cardHolderName = scanner.nextLine();
                    System.out.println("Enter CVV:");
                    String cvv = scanner.nextLine();
                    System.out.println("Enter expiry date:");
                    String expiryDate = scanner.nextLine();
                    context.setPaymentStrategy(new CreditCardPayment(cardNumber, cardHolderName, cvv, expiryDate));
                    break;
                case 2:
                    scanner.nextLine();  // Consume newline
                    System.out.println("Enter PayPal email:");
                    String email = scanner.nextLine();
                    System.out.println("Enter PayPal password:");
                    String password = scanner.nextLine();
                    context.setPaymentStrategy(new PayPalPayment(email, password));
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    continue;
            }

            context.pay(amount);
        }

        scanner.close();
    }
}
