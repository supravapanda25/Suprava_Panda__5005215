public class SquareGateway {
    public void executePayment(double amount) {
        System.out.println("Processing payment of $" + amount + " through Square.");
    }
}