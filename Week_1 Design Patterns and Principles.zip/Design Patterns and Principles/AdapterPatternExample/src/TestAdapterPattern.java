// TestAdapterPattern.java
public class TestAdapterPattern {
    public static void main(String[] args) {
        // Using PayPal through the adapter
        PayPalGateway payPalGateway = new PayPalGateway();
        PaymentProcessor payPalProcessor = new PayPalAdapter(payPalGateway);
        payPalProcessor.processPayment(100.0);

        // Using Stripe through the adapter
        StripeGateway stripeGateway = new StripeGateway();
        PaymentProcessor stripeProcessor = new StripeAdapter(stripeGateway);
        stripeProcessor.processPayment(200.0);

        // Using Square through the adapter
        SquareGateway squareGateway = new SquareGateway();
        PaymentProcessor squareProcessor = new SquareAdapter(squareGateway);
        squareProcessor.processPayment(300.0);
    }
}
