import java.util.Scanner;

public class TestCommandPattern {
    public static void main(String[] args) {
        Light livingRoomLight = new Light();
        Command lightOn = new LightOnCommand(livingRoomLight);
        Command lightOff = new LightOffCommand(livingRoomLight);

        RemoteControl remoteControl = new RemoteControl();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Enter command: 1. Turn Light On 2. Turn Light OFF 3. Exit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    remoteControl.setCommand(lightOn);
                    break;
                case 2:
                    remoteControl.setCommand(lightOff);
                    break;
                case 3:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    continue;
            }

            remoteControl.pressButton();
        }
    }
}
