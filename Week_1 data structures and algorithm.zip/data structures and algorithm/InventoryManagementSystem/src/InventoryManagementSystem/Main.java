package InventoryManagementSystem;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {
    private List<Product> products;

    public Main() {
        products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        for(Product p : products) {
            if(p.getProductId()==product.getProductId()) {
                System.out.println("Product with ID" + product.getProductId() + " already exists.");
                return;
            }
        }
        products.add(product);
        System.out.println("Product " +product.getProductName() + " added successfully.");
    }
    public void updateProduct(int productId, Integer newQuantity, Double newPrice) {
        for (Product product : products) {
            if (product.getProductId() == productId) {
                if (newQuantity != null) {
                    product.setQuantity(newQuantity);
                }
                if (newPrice != null) {
                    product.setPrice(newPrice);
                }
                System.out.println("Product with ID " + productId + " updated successfully.");
                return;
            }
        }
        System.out.println("Product with ID " + productId + " does not exist.");
    }
    public void deleteProduct(int productId) {
        Iterator<Product> iterator = products.iterator();
        while (iterator.hasNext()) {
            Product product = iterator.next();
            if (product.getProductId() == productId) {
                iterator.remove();
                System.out.println("Product with ID " + productId + " deleted successfully.");
                return;
            }
        }
        System.out.println("Product with ID " + productId + " does not exist.");
    }

    public void printInventoryProducts(){
        for(Product product : products) {
            System.out.println(product);
        }
    }
    public static void main(String[] args) {
        Main inventorySystem = new Main();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nInventory Management System:");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. View Inventory");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Product ID: ");
                    int id = scanner.nextInt();
                    System.out.print("Enter Product Name: ");
                    String name = scanner.next();
                    System.out.print("Enter Quantity: ");
                    int quantity = scanner.nextInt();
                    System.out.print("Enter Price: ");
                    double price = scanner.nextDouble();
                    Product product = new Product(id, name, quantity, price);
                    inventorySystem.addProduct(product);
                    break;
                case 2:
                    System.out.print("Enter Product ID to update: ");
                    int updateId = scanner.nextInt();
                    System.out.print("Enter new Quantity (or -1 to skip): ");
                    int newQuantity = scanner.nextInt();
                    System.out.print("Enter new Price (or -1 to skip): ");
                    double newPrice = scanner.nextDouble();
                    inventorySystem.updateProduct(updateId, newQuantity == -1 ? null : newQuantity, newPrice == -1 ? null : newPrice);
                    break;
                case 3:
                    System.out.print("Enter Product ID to delete: ");
                    int deleteId = scanner.nextInt();
                    inventorySystem.deleteProduct(deleteId);
                    break;
                case 4:
                    inventorySystem.printInventoryProducts();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }


}



