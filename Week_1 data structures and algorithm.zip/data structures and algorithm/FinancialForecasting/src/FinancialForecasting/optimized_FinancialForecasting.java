package FinancialForecasting;
import java.util.HashMap;
import java.util.Map;

public class optimized_FinancialForecasting {

    public static double predictFutureValue(double initialValue, double growthRate, int years, Map<Integer, Double> memo) {
        if (years == 0) {
            return initialValue;
        }

        if (memo.containsKey(years)) {
            return memo.get(years);
        }

        double previousValue = predictFutureValue(initialValue, growthRate, years - 1, memo);
        double futureValue = previousValue * (1 + growthRate);

        memo.put(years, futureValue);

        return futureValue;
    }

    public static void main(String[] args) {
        double initialValue = 1000.0; // Initial value
        double growthRate = 0.05; // Annual growth rate (5%)
        int years = 10; // Number of years into the future

        Map<Integer, Double> memo = new HashMap<>();

        double futureValue = predictFutureValue(initialValue, growthRate, years, memo);
        System.out.printf("Future value after %d years: %.2f%n", years, futureValue);
    }
}
