package e_CommercePaltformSearchFunction;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;


public class searchFunctions {

    //Linear search method
    public static Product linearSearch(Product[] products, int productId){
        for(Product product : products){
            if (product.getProductID() == productId){
                return product;
            }
        }
        return null;
    }
    //Binary search method
    public static Product binarySearch(Product[] products, int productId){
        Arrays.sort(products, Comparator.comparingInt(Product:: getProductID));
        int left=0;
        int right=products.length-1;

        while(left <= right){
            int mid = (left+right)/2;
            if (products[mid].getProductID() == productId) {
                return products[mid];
            }
            if (products[mid].getProductID() < productId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
    public static void main(String[] args) {
        Product[] products = {
                new Product(101, "Laptop", "Electronics"),
                new Product(102, "Mouse", "Electronics"),
                new Product(103, "Keyboard", "Electronics"),
                new Product(104, "Monitor", "Electronics"),
                new Product(105, "Printer", "Electronics")
        };

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nChoose search method:");
            System.out.println("1. Linear Search");
            System.out.println("2. Binary Search");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            if (choice == 3) {
                System.out.println("Exiting...");
                break;
            }

            System.out.print("Enter Product ID to search: ");
            int productId = scanner.nextInt();


            switch (choice) {
                case 1:
                    // Perform linear search
                    System.out.println("Linear Search:");
                    Product linearResult = searchFunctions.linearSearch(products, productId);
                    if (linearResult != null) {
                        System.out.println("Product found: " + linearResult);
                    } else {
                        System.out.println("Product not found.");
                    }

                    break;

                case 2:
                    // Perform binary search
                    System.out.println("Binary Search:");
                    Product binaryResult = searchFunctions.binarySearch(products, productId);
                    if (binaryResult != null) {
                        System.out.println("Product found: " + binaryResult);
                    } else {
                        System.out.println("Product not found.");
                    }

                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

        scanner.close();
    }

}